#include <stdio.h>
#include <stdlib.h>
#include "lobster.h"

int main() {
    struct item *items;
    int no_items;
    int net_capacity = 0;

    printf("Capacitatea plasei: ");
    scanf("%d", &net_capacity);
    printf("Nr de homari disponibili: ");
    scanf("%d", &no_items);

    items = malloc(no_items * sizeof(struct item));
    if (items == NULL) {
        fprintf(stderr, "Eroare la alocarea memoriei.\n");
        return 1;
    }

    generate_items(items, no_items);
    printf("\n=== Homari disponibili ===");
    print_items(items, no_items);

    sort_items_by_value(items, no_items);
    printf("\n=== Homari sortați după valoare ===");
    print_items(items, no_items);

    greedy_lobster_selection(items, no_items, net_capacity);

    free(items);
    return 0;
}
