#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "lobster.h"

void generate_items(struct item *items, int no_items) {
    time_t t;
    srand((unsigned) time(&t));
    for (int i = 0; i < no_items; i++) {
        items[i].id = i;
        items[i].size = rand() % 50 + 1;
        items[i].value = rand() % 50 + 1;
    }
}

void print_items(struct item *items, int no_items) {
    printf("\n Homari disponibili:");
    for (int i = 0; i < no_items; i++) {
        printf("\nHomarul:%d    Dimensiune:%d cm    Valoare:%d monede de aur",
               items[i].id, items[i].size, items[i].value);
    }
    printf("\n");
}

void sort_items_by_value(struct item *items, int no_items) {
    for (int i = 0; i < no_items - 1; i++) {
        int index_max = i;
        for (int j = i + 1; j < no_items; j++) {
            if (items[j].value > items[index_max].value) {
                index_max = j;
            }
        }
        if (index_max != i) {
            struct item temp = items[i];
            items[i] = items[index_max];
            items[index_max] = temp;
        }
    }
}

void greedy_lobster_selection(struct item *items, int no_items, int net_capacity) {
    int net_current_capacity = 0;
    int net_value = 0;
    int any_selected = 0;

          printf("\nHomarii alesi de pescar sunt: \n");
    for (int i = 0; i < no_items; i++) {
        if (net_current_capacity + items[i].size <= net_capacity) {
            if (any_selected) {
                printf(", ");
            }
            net_current_capacity += items[i].size;
            net_value += items[i].value;
            printf("%d", items[i].id);
            any_selected = 1;
        }
    }

    if (!any_selected) {
        printf("Niciun homar.");
    } else {
        printf(".");
    }

    printf("\nValoarea crustaceului din plasa de pescuit: %d", net_value);
}
