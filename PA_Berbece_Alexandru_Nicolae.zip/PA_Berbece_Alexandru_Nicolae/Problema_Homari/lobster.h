#ifndef LOBSTER_H
#define LOBSTER_H

struct item {
    int id;
    int size;
    int value;
};

void generate_items(struct item *items, int no_items);
void print_items(struct item *items, int no_items);
void sort_items_by_value(struct item *items, int no_items);
void greedy_lobster_selection(struct item *items, int no_items, int net_capacity);

#endif // LOBSTER_H
